Node attributes:	[x, y]

Class labels were converted to integer values using this map:

	0	K
	1	N
	2	L
	3	Z
	4	T
	5	X
	6	F
	7	V
	8	Y
	9	W
	10	H
	11	A
	12	I
	13	E
	14	M


