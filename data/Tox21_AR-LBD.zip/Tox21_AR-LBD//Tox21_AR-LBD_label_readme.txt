Node labels were converted to integer values using this map:

Component 0:
	0	Cl
	1	C
	2	N
	3	O
	4	Hg
	5	S
	6	F
	7	Br
	8	B
	9	Na
	10	K
	11	Zn
	12	P
	13	Sn
	14	I
	15	As
	16	Au
	17	Se
	18	Co
	19	Si
	20	Ca
	21	Li
	22	Pt
	23	Al
	24	Cu
	25	Bi
	26	Ag
	27	Ba
	28	Fe
	29	Ti
	30	Tl
	31	Sr
	32	Dy
	33	Ni
	34	Cr
	35	Sb
	36	Be
	37	Mg
	38	Nd
	39	Pd
	40	In
	41	Mn
	42	Zr
	43	Pb
	44	Yb
	45	Mo
	46	Cd
	47	Ge



Edge labels were converted to integer values using this map:

Component 0:
	0	single
	1	aromatic
	2	double
	3	triple



