Node attributes:	[x, y]

Class labels were converted to integer values using this map:

	0	N
	1	H
	2	M
	3	A
	4	W
	5	Y
	6	I
	7	F
	8	V
	9	T
	10	X
	11	Z
	12	K
	13	E
	14	L


