Node attributes:	[x, y]

Edge labels:		[valence]

Edge labels were converted to integer values using this map:

Component 0:
	0	2
	1	1



